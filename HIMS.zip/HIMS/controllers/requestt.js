const axios = require('axios');

exports.getToken=getToken;
function getToken(){
  return new Promise(function (reslove,reject){
    const data = {
      id: 'admin',
      secret: 'adminpw'
    }
    var header = {'header': 'Authorization: Bearer '};
    
    axios
.post('http://localhost:8801/user/enroll', data,header)
.then(res => {
  reslove({flg:0,st:res.status,tok:res.data.token}) ;
})
.catch(err => {
  reject({flg:1});
})

  })
   
}

exports.Transaction=Transaction;
function Transaction(method, args,token){
  return new Promise(function (reslove,reject){
    const data = {
      //{\"method\": \"ReadAsset\",\"args\": [ \"asset1\"]}
      "method": method,
      "args": args,
    }
    var headers = {
      headers: { 'Authorization': 'Bearer ' + token }
    }
    axios
  .post('http://localhost:8801/invoke/my-channel/chaincode1',data, headers)
  .then(res => {
  reslove({flg:0,st:res.status,data:res.data}) ;
  })
  .catch(err => {
  reject({flg:2,st:err.response.status});
  });
  })
  
  }
  exports.makeTransaction=makeTransaction
  async function makeTransaction(method, args){
    try{ 
      const outpot = await getToken();
      console.log(outpot)
      if(outpot.flg==0 && outpot.st==200){
        const result=await Transaction(method,args,outpot.tok)
        return result.data.response;
      }else{
        return 1
      }
    }catch(err){
      console.log(err);
    }
   
  }



